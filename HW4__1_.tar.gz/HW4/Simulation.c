#include <stdio.h>
#include <stdlib.h>

/* If there are custom classes/source files that you write, with
   custom functions, and you want those functions available for use in
   THIS .c file, then include the header file for the custom .c
   file(s) you've written, using the #include directive. For example:

   #include "SomeFile.h"

 */

void Simulate(char* fileName1, char* fileName2, char allocation) {
  // A function whose inputs are the trace files names and the allocation 
  // strategy 's' for split or 'f' for free for all

  
}

int main() {
  // Run simulation


}
