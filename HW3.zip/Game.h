header Game

  uses System, Thread, Synch

  functions
    main ()

endHeader
